package com.ichrak.produits.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ichrak.produits.entities.Produit;

public interface ProduitRepository extends JpaRepository<Produit, Long> {

}
